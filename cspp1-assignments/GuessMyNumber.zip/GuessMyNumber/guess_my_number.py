#Guess My Number Exercise

def main():
	s = raw_input()
	#your code here

if __name__== "__main__":
	main()